define(['header'], function(){
  'use strict';

  // console.log('before init | module: footer');

  var footer = (function(){
    var init = function(){

      // console.log('module: footer');

    };

    return{
      init: init
    };
  })();

  return footer;
});

	
	
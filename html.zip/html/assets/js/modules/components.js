define([], function(){
  'use strict';

  var home = (function(){
    var init = function(){

      console.log('module: components');

      $(document).ready(function() {
        
      });

    };

    return{
      init: init
    };
  })();

  return home;
});

	
	